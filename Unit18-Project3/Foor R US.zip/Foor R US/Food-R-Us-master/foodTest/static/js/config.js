// API key
const API_KEY = "pk.eyJ1Ijoic2FtamFkIiwiYSI6ImNrNjAyanNzeDAzb28zbG1nM3VndWN3M20ifQ.CQzEjHGQvYhWV6ewZ1v5AA";
